create trigger PCPRICEMONITORING
    after update of PRICE
    on PC
    for each row
    when (OLD.price <> NEW.price)
DECLARE
    tempType CHAR(10);
BEGIN
    SELECT type
    INTO tempType
    FROM Product
    WHERE model = :NEW.model;
    INSERT INTO Product_Monitoring VALUES (:NEW.model, tempType, :OLD.price, :NEW.price, TO_CHAR(SYSDATE, 'dd-mm-yyyy: hh24:mi'));
END;
/

