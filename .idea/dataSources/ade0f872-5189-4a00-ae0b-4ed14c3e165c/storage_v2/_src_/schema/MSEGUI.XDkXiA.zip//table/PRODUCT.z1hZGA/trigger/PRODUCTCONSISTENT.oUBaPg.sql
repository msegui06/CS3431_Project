create trigger PRODUCTCONSISTENT
    after insert or update of TYPE
    on PRODUCT
    for each row
DECLARE
    existingUnits NUMBER;
BEGIN
    IF :NEW.type = 'PC'
    THEN SELECT COUNT(*) INTO existingUnits
         FROM PC
         WHERE model = :NEW.model;

         IF existingUnits = 0
         THEN RAISE_APPLICATION_ERROR(-20004, 'Product marked as PC, but does not exist in PC table');
         END IF;
    ELSIF :NEW.type = 'Laptop'
    THEN SELECT COUNT(*) INTO existingUnits
         FROM Laptop
         WHERE model = :NEW.model;

         IF existingUnits = 0
         THEN RAISE_APPLICATION_ERROR(-20005, 'Product marked as Laptop, but does not exist in Laptop table');
         END IF;

    ELSIF :NEW.type IS NULL
    THEN SELECT COUNT(*) INTO existingUnits
         FROM PC
         WHERE model = :NEW.model;

         IF existingUnits = 0
         THEN RAISE_APPLICATION_ERROR(-20006, 'Product type is NULL but exists in PC');
         END IF;

         SELECT COUNT(*) INTO existingUnits
         FROM Laptop
         WHERE model = :NEW.model;
         IF existingUnits = 0
         THEN RAISE_APPLICATION_ERROR(-20007, 'Product type is NULL but exists in Laptop');
         END IF;
    END IF;
END;
/

