create trigger ICUCOMMENT
    before insert or update
    on EXAMINE
    for each row
DECLARE
numVisit NUMBER;
BEGIN
SELECT COUNT(*)
INTO numVisit
FROM StayIn s
         JOIN RoomService r ON s.roomNum = r.roomNum
WHERE s.admissionNum = :NEW.admissionNum
  AND r.service = 'ICU';
IF numVisit > 0 AND :NEW.doctorComment IS NULL THEN
        RAISE_APPLICATION_ERROR(-20000, 'Doctor must leave a comment for ICU patients');
END IF;
END;
/

