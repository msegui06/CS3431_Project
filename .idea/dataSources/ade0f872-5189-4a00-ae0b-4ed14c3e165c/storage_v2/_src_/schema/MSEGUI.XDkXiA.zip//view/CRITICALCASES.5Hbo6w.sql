create view CRITICALCASES as
SELECT p.SSN AS Patient_SSN, p.firstName, p.lastName, COUNT(a.admissionNum) AS numberOfAdmissionsToICU
FROM Admission a 
    JOIN Patient p 
        ON a.SSN = p.SSN
    JOIN StayIn s 
        ON a.admissionNum = s.admissionNum
    JOIN RoomService r 
        ON s.roomNum = r.roomNum 
WHERE r.service = 'ICU'
GROUP BY p.SSN, p.firstName, p.lastName
HAVING COUNT(a.admissionNum) >= 2
/

