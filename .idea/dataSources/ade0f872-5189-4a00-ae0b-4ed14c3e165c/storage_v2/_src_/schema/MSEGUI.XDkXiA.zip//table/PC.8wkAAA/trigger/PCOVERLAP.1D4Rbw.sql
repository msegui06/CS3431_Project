create trigger PCOVERLAP
    before insert or update
    on PC
    for each row
DECLARE
    existingUnits NUMBER;
BEGIN
    SELECT COUNT(*) INTO existingUnits 
    FROM Laptop
    WHERE model = :NEW.model;
    IF existingUnits > 0
    THEN RAISE_APPLICATION_ERROR (-20000, 'Error: This model already exists in Laptop.');
    END IF;
END;
/

