create view DOCTORSLOAD as
SELECT d.employeeID AS doctorID, d.graduatedFrom, 
    CASE
        WHEN COUNT(DISTINCT e.admissionNum) > 10 THEN 'overloaded'
        ELSE 'underloaded'
    END AS load
FROM Doctor d LEFT 
    JOIN Examine e 
        ON d.employeeID = e.doctorID
GROUP BY d.employeeID, d.graduatedFrom
/

