create trigger ERPOSTVISIT
    after insert
    on STAYIN
    for each row
DECLARE
numVisit NUMBER;
BEGIN
SELECT COUNT(*)
INTO numVisit
FROM RoomService
WHERE roomNum = :NEW.roomNum
  AND service = 'ER';
IF numVisit > 0 THEN
UPDATE Admission
SET futureVisit = ADD_MONTHS(:NEW.startDate, 2)
WHERE admissionNum = :NEW.admissionNum;
END IF;
END;
/

