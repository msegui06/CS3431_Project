create trigger INSPECTEQUIPMENT
    before insert
    on EQUIPMENT
    for each row
DECLARE
    numEquip NUMBER;
BEGIN
    IF MONTHS_BETWEEN(SYSDATE, :NEW.lastInspection) > 1 THEN
        SELECT COUNT(*)
        INTO numEquip
        FROM CanRepairEquipment c
            JOIN EquipmentTechnician t ON c.employeeID = t.employeeID
        WHERE c.equipmentType = :NEW.typeID;

        IF numEquip > 0 THEN
            :NEW.lastInspection := SYSDATE;
        END IF;
    END IF;
END;
/

