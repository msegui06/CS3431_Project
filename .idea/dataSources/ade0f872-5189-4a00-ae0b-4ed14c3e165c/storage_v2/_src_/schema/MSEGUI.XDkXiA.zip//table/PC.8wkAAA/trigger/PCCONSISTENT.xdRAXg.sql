create trigger PCCONSISTENT
    before insert
    on PC
    for each row
DECLARE
    existingUnits NUMBER;
    tempType CHAR(10);
BEGIN
    SELECT COUNT(*) INTO existingUnits
    FROM Product
    WHERE model = :NEW.model;

    IF existingUnits = 0
    THEN INSERT INTO Product (model, manufacturer, type) VALUES (:NEW.model, 'NA', 'PC');

    ELSE SELECT type INTO tempType
         FROM Product
         WHERE model = :NEW.model;

         IF tempType <> 'PC'
         THEN RAISE_APPLICATION_ERROR(-20002, 'Product type does not align: must be PC.');
         END IF;
    END IF;
END;
/

