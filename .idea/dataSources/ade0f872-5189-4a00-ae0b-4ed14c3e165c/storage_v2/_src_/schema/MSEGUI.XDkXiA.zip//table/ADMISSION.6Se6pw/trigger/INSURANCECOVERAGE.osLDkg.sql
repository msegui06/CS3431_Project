create trigger INSURANCECOVERAGE
    before insert or update of TOTALPAYMENT
    on ADMISSION
    for each row
BEGIN
    :NEW.insurancePayment := :NEW.totalPayment * 0.65;
END;
/

