create trigger CHECKEMPRANKS
    before insert or update
    on EMPLOYEE
    for each row
DECLARE
supRank varchar2(100);
BEGIN
    IF :NEW.empRank = '0' THEN
        IF :NEW.supervisorID IS NULL THEN
            RAISE_APPLICATION_ERROR(-20001, 'Regular Employees must have supervisors.');
END IF;

SELECT empRank INTO supRank
FROM Employee
WHERE employeeID = :NEW.supervisorID;

IF supRank <> '1' THEN
            RAISE_APPLICATION_ERROR(-20002, 'Regular Employee supervisor must be rank 1.');
END IF;

    ELSIF :NEW.empRank = '1' THEN
        IF :NEW.supervisorID IS NULL THEN
            RAISE_APPLICATION_ERROR(-20003, 'Division managers must have supervisors.');
END IF;

SELECT empRank INTO supRank
FROM Employee
WHERE employeeID = :NEW.supervisorID;

IF supRank <> '2' THEN
            RAISE_APPLICATION_ERROR(-20004, 'Division managers supervisor must be rank 2.');
END IF;

    ELSIF :NEW.empRank = '2' THEN
        IF :NEW.supervisorID IS NOT NULL THEN
            RAISE_APPLICATION_ERROR(-20005, 'General managers cannot have supervisors.');
END IF;
END IF;
END;
/

